# A fake V8

The V8 library is a massive and unnecessary dependency for JASP that is quite difficult to compile on flatpak. This fake package is a workaround. If you're not interested in JASP or flatpak, you probably don't want to use this at all.
